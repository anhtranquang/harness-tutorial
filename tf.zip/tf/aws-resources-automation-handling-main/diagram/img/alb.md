```mermaid
sequenceDiagram
    participant Scheduler
    participant Handler #lightGreen
    participant ALB #LightGoldenRodYellow

    Scheduler ->> Handler: Event
    activate Handler #lightGreen
    activate ALB #LightGoldenRodYellow
    Handler -> ALB: List all ELBs
    ALB --> Handler : list_lbs  
    deactivate ALB
    Handler ->> Handler: Filter for ALB with type == "application"
    Handler ->> ALB: Describe ALB Attributes
    activate ALB #LightGoldenRodYellow
    ALB -->> Handler: Response
    deactivate ALB
    Handler ->> Handler: Filter for ALB not enable access log,<br/> access_logs.s3.enabled == false
    Handler ->> ALB: Modify ALB attribute
    activate ALB #LightGoldenRodYellow
    ALB -->> Handler: Success
    Note right of Handler:   { "Key": "access_logs.s3.enabled", "Value": "true" },<br/>{ "Key": "access_logs.s3.bucket", "Value": bucket_name },<br/>{ "Key": "access_logs.s3.prefix", "Value": alb_name }
    deactivate ALB
    deactivate Handler
```
