import boto3
import logging
from os import getenv
from json import loads

# Configure logging
logger = logging.getLogger()
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(
        "[%(asctime)s] %(levelname)s:%(funcName)s:%(lineno)s:%(message)s",
        "%Y-%m-%d %H:%M:%S",
    ))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    lambda_configs = loads(getenv("lambda_configs"))
    region_name = lambda_configs.get("region")
    input_tags = event.get("tags", {})
    action = event.get("action", "").lower()
    operator = event.get("operator", "in")
    
    instance_process = []
    
    if not action or action not in ["start", "stop"]:
        logger.error("Invalid or missing action. Must be 'start' or 'stop'.")
        return {
            "status": "failure",
            "message": "Invalid action. Expected 'start' or 'stop'."
        }

    try:
        tags = convert(input_tags)
        client = boto3.client(service_name="rds", region_name=region_name)
        instance_ids = process_aurora(client, tags, operator)
        
        if not instance_ids:
            logger.info(f"No matching Aurora clusters found for tags: {input_tags}")
            return {
                "status": "success",
                "message": f"No matching Aurora clusters found for {tags}"
            }
        
        if action == "start":
            instance_process = start(client, instance_ids)
        elif action == "stop":
            instance_process = stop(client, instance_ids)

        instance_remain = [i for i in instance_ids if i not in instance_process]
        return {
            "status": "success",
            "message": f"Finished {action} process for {instance_process}, failed process for {instance_remain if instance_remain else 'none'}"
        }
        
    except Exception as e:
        logger.error(f"Error occurred: {e}")
        return {
            "status": "failure",
            "message": f"An error occurred: {str(e)}"
        }

def process_aurora(client, tags, operator):
    instance_process = []
    try:
        response = client.describe_db_clusters()
        for r in response["DBClusters"]:
            try:
                if r["Engine"] != "docdb":  # Skip non-Aurora clusters
                    if operator == "in" and all(x in r["TagList"] for x in tags):
                        instance_process.append(r["DBClusterIdentifier"])
                    elif operator == "notin" and all(x not in r["TagList"] for x in tags):
                        instance_process.append(r["DBClusterIdentifier"])
            except KeyError as e:
                logger.error(f"KeyError in cluster {r.get('DBClusterIdentifier', 'unknown')}: {e}")
            except Exception as e:
                logger.error(f"Error processing cluster {r.get('DBClusterIdentifier', 'unknown')}: {type(e).__name__}: {e}")
    except Exception as e:
        logger.error(f"Error in process_aurora: {e}")
        raise
    return instance_process

def start(client, instance_ids):
    instance_process = []
    failed_instances = []
    
    for instance_id in instance_ids:
        try: 
            # Get the current state of the cluster
            current_state = get_cluster_status(client, instance_id)
            if current_state != 'stopped':
                logger.info(f"Cluster {instance_id} is in '{current_state}' state and cannot be started.")
                continue
            
            logger.info(f"Starting Aurora Cluster {instance_id}")
            response = client.start_db_cluster(DBClusterIdentifier=instance_id)
            instance_process.append(instance_id)
            logger.info(f"Start response: {response}")
        except Exception as e:
            logger.error(f"Error starting Aurora cluster {instance_id}: {e}")
            failed_instances.append(instance_id)
    
    if failed_instances:
        logger.error(f"Failed to start clusters: {failed_instances}")
    
    logger.info(f"Successfully started clusters: {instance_process}")
    return instance_process

def stop(client, instance_ids):
    instance_process = []
    failed_instances = []
    
    for instance_id in instance_ids:
        try:
            # Get the current state of the cluster
            current_state = get_cluster_status(client, instance_id)
            if current_state != 'available':
                logger.info(f"Cluster {instance_id} is in '{current_state}' state and cannot be stopped.")
                continue
            
            logger.info(f"Stopping Aurora Cluster {instance_id}")
            response = client.stop_db_cluster(DBClusterIdentifier=instance_id)
            instance_process.append(instance_id)
            logger.info(f"Stop response: {response}")
        except Exception as e:
            logger.error(f"Error stopping Aurora cluster {instance_id}: {e}")
            failed_instances.append(instance_id)
    
    if failed_instances:
        logger.error(f"Failed to stop clusters: {failed_instances}")
    
    logger.info(f"Successfully stopped clusters: {instance_process}")
    return instance_process

def get_cluster_status(client, cluster_id):
    """Helper function to get the current state of the DB cluster"""
    try:
        response = client.describe_db_clusters(DBClusterIdentifier=cluster_id)
        return response['DBClusters'][0]['Status']
    except Exception as e:
        logger.error(f"Error retrieving status for {cluster_id}: {e}")
        raise

def convert(input_tags):
    return [{"Key": k.strip(), "Value": v.strip()} for k, v in input_tags.items()]
