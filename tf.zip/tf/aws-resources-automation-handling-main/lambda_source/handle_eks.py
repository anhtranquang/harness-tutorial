import boto3, sys
import logging
from os import getenv
from json import loads, dumps
logger = logging.getLogger()
handler = logger.handlers[0]
handler.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(levelname)s:%(funcName)s:%(lineno)s:%(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
)
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    lambda_configs = loads(getenv("lambda_configs"))
    ec2_client = boto3.client(service_name="ec2")
    eks_client = boto3.client(service_name="eks")
    ssm_client = boto3.client(service_name="ssm")
    region_name = lambda_configs["region"]
    input_tags = event["tags"]
    input_tags_tuple = [(k, v) for k, v in input_tags.items()]
    operator   = event.get("operator", "in")
    action = event["action"]
    list_processed_instance = []
    try:        
        clusters = collect_clusters(eks_client, input_tags_tuple, operator)
        for cluster in clusters:
            cluster_name = cluster['name']
            list_nodegroups = describe_nodegroup(eks_client, cluster_name)
            for ng_infor in list_nodegroups:
                ng_name = ng_infor['nodegroupName']
                params = get_param(ssm_client, cluster_name, ng_name)
                if params == 1:
                    put_params(ssm_client, ng_infor['scalingConfig'], cluster_name, ng_name)
                    params = get_param(ssm_client, cluster_name, ng_name)
                if action.lower() == "start":
                    instance_process = start(eks_client, cluster_name,  ng_name, params)
                elif action.lower() == "stop":
                    instance_process = stop(eks_client, ec2_client, ssm_client, cluster_name, ng_name, ng_infor)
                list_processed_instance.append(instance_process)
        return ("EKS!!! Finished {} process for {}".format(action, list_processed_instance))
    except Exception as e:
        logger.error(f"Error occur: {e}")
        sys.exit("Error!!")


def collect_clusters(eks_client, input_tags_tuple, operator):
    all_clusters = list_clusters(eks_client)
    cluster_to_process = []
    try: 
        for cluster in all_clusters:
            is_has_tag = False
            cluster_info = describe_cluster(eks_client, cluster)
            if cluster_info != {}:
                cluster_tag = cluster_info["tags"]
                for tag in input_tags_tuple:
                    if tag in cluster_tag.items():
                        is_has_tag = True
                        break
                match operator:
                    case "in":
                        if is_has_tag:
                            cluster_to_process.append(cluster_info)
                    case "notin":
                        if not is_has_tag:
                            cluster_to_process.append(cluster_info)    
    except Exception as e:
        logger.error(f"Error: {e}")
    return cluster_to_process

def list_clusters(eks_client):
    list_cluster = []
    try: 
        response =  eks_client.list_clusters()
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info(f"Finished list EKS cluster!")
            list_cluster = response["clusters"]
        else:
            logger.error(f"List EKS cluster error, Code {response['ResponseMetadata']['HTTPStatusCode']}, Message {response['ResponseMetadata']['HTTPStatusMessage']}")
    except Exception as e:
        logger.error(f"Error: {e}")  
    return list_cluster

def describe_cluster(eks_client, cluster_id):
    cluster_info = {}
    try: 
        response = eks_client.describe_cluster(name=cluster_id)
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info(f"Finished describe EKS cluster!")
            cluster_info = response["cluster"]
        else:
            logger.error(f"Describe  EKS cluster error, Code {response['ResponseMetadata']['HTTPStatusCode']}, Message {response['Error']['Message']}")
    except Exception as e:
        logger.error(f"Error: {e}")  
    return cluster_info

def describe_nodegroup(eks_client, cluster_name):
    list_nodegroups = []
    try:
        nodegroups = eks_client.list_nodegroups(clusterName=cluster_name)['nodegroups']
        for ng in nodegroups:
            ng_infor = eks_client.describe_nodegroup(clusterName=cluster_name,nodegroupName=ng)['nodegroup']
            list_nodegroups.append(ng_infor)
    except Exception as e:
        logger.error(f"Error: {e}")  
    return list_nodegroups

def get_param(client, cluster_name, ng_name):
    try:
        param = client.get_parameter(Name=f"/scheduler/eks/{cluster_name}/{ng_name}")
        logger.info(f"Param: {param}")
        return loads(param["Parameter"]["Value"])
    except Exception as e:
        logger.error(f"Func: get_param. Error: {e}")
        return 1
       
def put_params(client, ng_infor, cluster_name, ng_name):
    desired  = ng_infor["desiredSize"]
    min_size = ng_infor["minSize"]
    max_size = ng_infor["maxSize"]
    value = dumps({"desired": desired, "min": min_size, "max": max_size})
    logger.info(f"Start to put scheduler eks param {value} for: {ng_name}")
    try:
        params = [{
            "Name": f"/scheduler/eks/{cluster_name}/{ng_name}",
            "Value": str(value),
            "Type": "String",
            "Overwrite": True
        }]
        client.put_parameter(**params[0])
    except Exception as e:
        logger.error(f"Func: put_params. Error: {e}")
        return 1
    
def start(eks_client, cluster_name, nodegroup_name, params):    
    instance_process = []
    try: 
        logger.info(f"Start action for EKS cluster {cluster_name} node group {nodegroup_name}")
        response = eks_client.update_nodegroup_config(
                        clusterName=cluster_name,
                        nodegroupName=nodegroup_name,
                        scalingConfig={
                            'desiredSize': params["desired"],
                            'minSize': params["min"],
                            'maxSize': params["max"],
                        }
                    )
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info(f"{nodegroup_name} finished to update nodegroup config")
        else:
            logger.error(f"{nodegroup_name} error to update nodegroup config, Code {response['ResponseMetadata']['HTTPStatusCode']}")
        instance_process.append(nodegroup_name)
        logger.info(f"Started nodegroup {nodegroup_name}")
    except Exception as e:
        logger.error(f"Error while start EKS nodegroup: {nodegroup_name}")
        logger.error(f"Error: {e}")
    logger.info(f"Finished start instances: {instance_process}")
    return instance_process
    

def stop(eks_client, ec2_client, ssm_client, cluster_name, nodegroup_name, ng_infor):
    try:
        eks_client.update_nodegroup_config(
            clusterName=cluster_name,
            nodegroupName=nodegroup_name,
            scalingConfig={
                'desiredSize': 0,
                'minSize': 0
            }
            )
        logger.info(f"Scaling down node group {nodegroup_name} of cluster {cluster_name} to 0")

        # Terminate EC2 instances with the specified tag
        instances = ec2_client.describe_instances(
            Filters=[
            {'Name': 'tag:aws:eks:cluster-name', 'Values': [cluster_name]},
            {'Name': 'instance-state-name', 'Values': ['running']}  # Target running instances
            ]
        )['Reservations']

        instance_ids = [instance['InstanceId'] for reservation in instances for instance in reservation['Instances']]
        if instance_ids:
            ec2_client.terminate_instances(InstanceIds=instance_ids)
            logger.info(f"Terminated all {len(instances)} nodes of cluster {cluster_name}")
            put_params(ssm_client, ng_infor['scalingConfig'], cluster_name, nodegroup_name)
        logger.info(f"Finished stop nodegroup: {nodegroup_name}")
    except Exception as e:
        logger.error(f"Error while stop EKS nodegroup: {nodegroup_name}")
        logger.error(f"Error: {e}")
    return nodegroup_name
