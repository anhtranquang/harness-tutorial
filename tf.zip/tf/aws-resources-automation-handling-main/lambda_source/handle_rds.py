import boto3
import sys
import logging
from os import getenv
from json import loads

# Set up logging configuration
logger = logging.getLogger()
handler = logger.handlers[0]
handler.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(levelname)s:%(funcName)s:%(lineno)s:%(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
)
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    Main Lambda function handler to start/stop RDS instances based on tags.
    """
    try:
        # Load configurations
        lambda_configs = loads(getenv("lambda_configs"))
        region_name = lambda_configs["region"]
        input_tags = event["tags"]
        action = event["action"].lower()  # Ensure case insensitivity
        operator = event.get("operator", "in")
        
        # Convert tags to a format compatible with AWS tag filters
        tags = convert(input_tags)

        # Initialize boto3 session and RDS client
        session = boto3.session.Session()
        client = session.client(service_name="rds", region_name=region_name)

        # Process RDS instances based on tags and operator
        instance_ids = process_rds(client, tags, operator)
        logger.info(f"{action.capitalize()} action for RDS Instances: {instance_ids}")

        # Perform the action (start/stop)
        if action == "start":
            instance_process = start_instances(client, instance_ids)
        elif action == "stop":
            instance_process = stop_instances(client, instance_ids)
        else:
            raise ValueError(f"Unsupported action: {action}")
        
        # Identify instances that failed the process
        instance_remain = [i for i in instance_ids if i not in instance_process]
        return {
            "message": f"Finished {action} process for {instance_process}, "
                       f"failed process for {instance_remain if instance_remain else 'none'}"
        }
    except Exception as e:
        logger.error(f"Error occurred: {e}")
        return {"message": f"Error: {str(e)}"}

def process_rds(client, tags, operator):
    """
    Fetches and processes RDS instances based on the provided tags and operator.
    """
    instance_process = []
    try:
        # Describe DB instances to get their tags
        response = client.describe_db_instances()
        for r in response["DBInstances"]:
            # Ensure instance is not a DocumentDB instance
            if r["Engine"] == "docdb":
                continue

            # Perform tag matching based on the operator (in or notin)
            tag_list = r.get("TagList", [])
            if operator == "in" and all(tag in tag_list for tag in tags):
                instance_process.append(r["DBInstanceIdentifier"])
            elif operator == "notin" and all(tag not in tag_list for tag in tags):
                instance_process.append(r["DBInstanceIdentifier"])
    except Exception as e:
        logger.error(f"Error while processing RDS instances: {e}")
        raise
    return instance_process

def start_instances(client, instance_ids):
    """
    Starts the provided RDS instances if they are in a 'stopped' state.
    """
    instance_process = []
    failed_instances = []
    
    for instance_id in instance_ids:
        try:
            # Get the current status of the DB instance
            instance_status = client.describe_db_instances(DBInstanceIdentifier=instance_id)["DBInstances"][0]["DBInstanceStatus"]
            
            if instance_status == "stopped":
                logger.info(f"Starting RDS Instance: {instance_id}")
                response = client.start_db_instance(DBInstanceIdentifier=instance_id)
                instance_process.append(instance_id)
                logger.info(f"Started RDS Instance: {instance_id}")
            else:
                # Log if instance is not in a valid state to be started
                logger.warning(f"RDS Instance {instance_id} cannot be started because it is in '{instance_status}' state.")
                failed_instances.append(instance_id)
        except Exception as e:
            failed_instances.append(instance_id)
            logger.error(f"Failed to start RDS Instance: {instance_id}")
            logger.error(f"Error: {e}")
    
    logger.info(f"Successfully started instances: {instance_process}")
    if failed_instances:
        logger.warning(f"Instances failed to start: {failed_instances}")
    
    return instance_process

def stop_instances(client, instance_ids):
    """
    Stops the provided RDS instances.
    """
    instance_process = []
    failed_instances = []
    
    for instance_id in instance_ids:
        try:
            # Describe the DB instance to get details
            instance_info = client.describe_db_instances(DBInstanceIdentifier=instance_id)["DBInstances"][0]
            instance_status = instance_info["DBInstanceStatus"]

            # Only stop the instance if it is in 'available' state
            if instance_status == "available":
                logger.info(f"Stopping RDS Instance: {instance_id}")
                client.stop_db_instance(DBInstanceIdentifier=instance_id)
                instance_process.append(instance_id)
                logger.info(f"Stopped RDS Instance: {instance_id}")
            else:
                logger.warning(f"RDS Instance {instance_id} cannot be stopped because it is in '{instance_status}' state.")
                failed_instances.append(instance_id)
        except Exception as e:
            failed_instances.append(instance_id)
            logger.error(f"Failed to stop RDS Instance: {instance_id}")
            logger.error(f"Error: {e}")
    
    logger.info(f"Successfully stopped instances: {instance_process}")
    if failed_instances:
        logger.warning(f"Instances failed to stop: {failed_instances}")
    
    return instance_process

def convert(input_tags):
    """
    Converts input tags from dict format to AWS tag format.
    """
    return [{"Key": k.strip(), "Value": v.strip()} for k, v in input_tags.items()]
