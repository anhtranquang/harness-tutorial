import boto3
import logging, time
from json import loads, dumps
from os import getenv
logger = logging.getLogger()
handler = logger.handlers[0]
handler.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(levelname)s:%(funcName)s:%(lineno)s:%(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
)
logger.setLevel(logging.INFO)
client = boto3.client('elbv2')
def lambda_handler(event, context):
    lambda_configs = loads(getenv("lambda_configs"))
    bucket_name = lambda_configs["bucket_name"]
    alb_not_enabled_access_logs_arns = list_not_enable_access_logs_alb()
    for arn, name in alb_not_enabled_access_logs_arns.items():
        update_alb_access_logs(arn, name, bucket_name)
    return 1

def list_not_enable_access_logs_alb():
    alb_arns = {}
    alb_not_enabled_access_logs_arns = {}
    try: 
        paginator = client.get_paginator('describe_load_balancers')
        response_iterator = paginator.paginate()
        for item in response_iterator:
            for alb in item['LoadBalancers']:
                if alb["Type"] == "application":
                    alb_arns.update({alb['LoadBalancerArn']: alb['LoadBalancerName']})
        for arn, name in alb_arns.items():
            response = client.describe_load_balancer_attributes(
                LoadBalancerArn= arn
            )
            for att in response["Attributes"]:
                if att["Key"] == "access_logs.s3.enabled" and att["Value"] == "false":
                    alb_not_enabled_access_logs_arns.update({arn: name})
                    break
        print(alb_not_enabled_access_logs_arns)
    except Exception as e:
        logger.error(f"Error: {e}")
    return alb_not_enabled_access_logs_arns

def update_alb_access_logs(arn, name, bucket):
    try: 
        response = client.modify_load_balancer_attributes(
            LoadBalancerArn=arn,
            Attributes=[
                {
                    'Key': 'access_logs.s3.enabled',
                    'Value': 'true'
                },
                {
                    'Key': 'access_logs.s3.bucket',
                    'Value': bucket
                },
                {
                    'Key': 'access_logs.s3.prefix',
                    'Value': name
                },
            ]
        )
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info(f"Finished modify_load_balancer_attributes for {name}")
        else:
            logger.error(f"Modify LB {name} error, Code {response['ResponseMetadata']['HTTPStatusCode']}, Message {response['Error']['Message']}")
    except Exception as e:
        logger.error(f"Error: {e}")
    return name
