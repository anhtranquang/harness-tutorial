import boto3, sys
import logging, time
from json import loads
from os import getenv
from multiprocessing import Process
logger = logging.getLogger()
handler = logger.handlers[0]
handler.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(levelname)s:%(funcName)s:%(lineno)s:%(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
)
logger.setLevel(logging.INFO)
cloudwatch = boto3.client('cloudwatch')
ssm = boto3.client('ssm')
ec2 = boto3.client('ec2')


def lambda_handler(event, context):
    try:
        input_tags = event["tags"]
        operator   = event.get("operator", "in")
        lambda_configs = loads(getenv("lambda_configs"))
        account_id = lambda_configs["account_id"]
        lambda_arn = f"arn:aws:lambda:ap-southeast-1:{account_id}:function:non-prod-extend-ebs-event-scheduling-function"
        threshold = 70.0
        instance_id = ""
        device = ""
        mount_path = ""
        filtered_metrics = filter_metrics()
        process_list = []
        tags = convert(input_tags)
        running_instances = list_all_running_instance(tags, operator)
        for metric in filtered_metrics:
            for d in metric.get("Dimensions"):
                match d["Name"]:
                    case "device":
                        device = d["Value"]
                    case "path":
                        mount_path = d["Value"]
                    case "InstanceId":
                        instance_id = d["Value"]
            if instance_id in running_instances.keys():
                print(f"Process {instance_id}")
                process = Process(target=process_ebs, args=(threshold, lambda_arn, device, instance_id, mount_path, running_instances[instance_id]))
                process_list.append(process)
            else:
                continue
        for process in process_list:
            process.start()
        for process in process_list:
            process.join()
    except Exception as e:
        logger.error(f"Error occur: {e}")
        sys.exit("Error!!")

def list_all_running_instance(tags, operator):
    running_instances = {}
    try:
        response = ec2.describe_instances(
            Filters=[{'Name': 'instance-state-name', 'Values': ['running']}]
        )
        if response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            logger.info(f"List instances successfully")
        else:
            logger.error(f"List instances failed, Error response: {response}")
            raise Exception
        for r in response["Reservations"]:
            for i in r["Instances"]:
                instance_id = i["InstanceId"]
                try:
                    if should_ignore(i["Tags"]):
                        continue
                    else:
                        match operator:
                            case "in":
                                if(all(x in i["Tags"] for x in tags)):
                                    instance_detail = {"InstanceId" : i["InstanceId"], "ImageId": i["ImageId"], "InstanceType": i["InstanceType"]}
                                    running_instances[i["InstanceId"]] =  instance_detail
                            case "notin":
                                if(all(x not in i["Tags"] for x in tags)):
                                    instance_detail = {"InstanceId" : i["InstanceId"], "ImageId": i["ImageId"], "InstanceType": i["InstanceType"]}
                                    running_instances[i["InstanceId"]] =  instance_detail
                except KeyError as e:
                    logger.error(f"KeyError: {e}, instance {instance_id}")
                    continue
                except Exception as e:
                    logger.error(f"Error occur: {type(e).__name__}")
                    continue
    except Exception as e:
        logger.error(f"Error occur: {e}")
        sys.exit("Error!!")
    return running_instances

def process_ebs(threshold, lambda_arn, device, instance_id, mount_path, instance_detail):
    fs = get_file_system(instance_id, device)
    # size = get_volume_size(volume_id)
    create_cloudwatch_alarm(threshold, lambda_arn, device, instance_id, mount_path, instance_detail, fs)

def get_file_system(instance_id, device):
    try:
        response = ssm.send_command(
            InstanceIds=[instance_id],
            DocumentName="AWS-RunShellScript",
            Parameters={'commands': ['df -hT | grep {} | awk \'{{print $2}}\''.format(device)]}, 
        )

        command_id = response['Command']['CommandId']
        time.sleep(2)
        output = ssm.get_command_invocation(
            CommandId=command_id,
            InstanceId=instance_id,
        )
        if output["StatusDetails"] == "Failed":
            raise Exception("Error getting volume id")
    except Exception as e:
        logger.error(f"Error: {e}")
    return output["StandardOutputContent"].strip()

def create_cloudwatch_alarm(threshold, lambda_arn, device, instance_id, mount_path, instance_detail, fs):
    try:
        cloudwatch.put_metric_alarm(
            AlarmName=f'EBS_Utilization_Overhead_{instance_id}_{device}',
            ComparisonOperator='GreaterThanThreshold',
            EvaluationPeriods=1,
            MetricName='disk_used_percent',
            Namespace='CWAgent',
            Period=300,
            Statistic='Maximum',
            Threshold=threshold,
            ActionsEnabled=True,
            AlarmActions=[lambda_arn],
            AlarmDescription=f'Alarm when server Disk exceeds {threshold}%',
            Dimensions=[
                    {
                        "Name": "path",
                        "Value": str(mount_path)
                    },
                    {
                        "Name": "InstanceId",
                        "Value": str(instance_id)
                    },
                    {
                        "Name": "device",
                        "Value": str(device)
                    },
                    {
                        "Name": "fstype",
                        "Value": str(fs)
                    },
                    {
                        "Name": "InstanceType",
                        "Value": str(instance_detail["InstanceType"])
                    },
                    {
                        "Name": "ImageId",
                        "Value": str(instance_detail["ImageId"])
                    },
                ]
        )
    except Exception as e:
        logger.error(f"Error: {e}")

def filter_metrics():
    try:
        filtered_metrics = []
        response = cloudwatch.list_metrics(
            Namespace='CWAgent',
            MetricName='disk_used_percent',
        )
        list_metrics = (response["Metrics"])
        for metric in list_metrics:
            is_root_block = False
            is_ebs = False
            for d in metric.get("Dimensions"):
                if d["Name"] == "path" and d["Value"] == "/":
                    is_root_block = True
                if d["Value"].startswith("nvme"):
                    is_ebs = True
            if not is_root_block and is_ebs:
                filtered_metrics.append(metric)
    except Exception as e:
        logger.error(f"Error: {e}")
    return filtered_metrics

def should_ignore(instance_tags):
    '''
        Return True if an instance should be ignored by instance scheduler.
        Currently we ignore if the instance is managed by Karpenter or Cloud9
        by looking at its tags
    
        Parameters:
            tags -- list of Key/Value tag object

        Returns:
            True if instance tags has a key name karpenter.sh/managed-by or aws:cloud9:owner
            False otherwise.
    '''
    
    for tag in instance_tags:
        if tag["Key"] in ["karpenter.sh/managed-by","aws:cloud9:owner"]:
            return True
    
    return False

def convert(input):
    tags = []
    for k, v in input.items():
        tags.append({"Key": k.strip(), "Value": v.strip()})
    return tags
