import boto3
import sys
import logging
from os import getenv
from json import loads
from concurrent.futures import ThreadPoolExecutor

# Logger setup
logger = logging.getLogger()
if not logger.handlers:
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(
        logging.Formatter(
            "[%(asctime)s] %(levelname)s:%(funcName)s:%(lineno)s:%(message)s", 
            "%Y-%m-%d %H:%M:%S"
        )
    )
    logger.addHandler(handler)
logger.setLevel(logging.INFO)

# Lambda handler
def lambda_handler(event, context):
    try:
        # Load configurations from environment variables
        lambda_configs = loads(getenv("lambda_configs"))
        region_name = lambda_configs.get("region")
        input_tags = event.get("tags")
        action = event["action"]
        operator = event.get("operator", "in")

        if action not in ["start", "stop"]:
            raise ValueError(f"Invalid action: {action}. Expected 'start' or 'stop'.")

        # Convert tags to AWS format
        tags = convert_tags(input_tags)

        # Boto3 session and client
        session = boto3.session.Session()
        client = session.client(service_name="docdb", region_name=region_name)

        # Get matching clusters based on tags
        cluster_ids = process_docdb(client, tags, operator)
        if not cluster_ids:
            logger.info("No matching DocumentDB clusters found.")
            return {"message": "No matching clusters to process."}

        # Perform the action (start or stop) on the clusters
        if action == "start":
            processed, failed = manage_clusters(client, cluster_ids, "start")
        elif action == "stop":
            processed, failed = manage_clusters(client, cluster_ids, "stop")

        return {
            "processed_clusters": processed,
            "failed_clusters": failed,
            "message": f"Finished {action} action. Processed: {processed}, Failed: {failed or 'none'}"
        }
    except Exception as e:
        logger.error(f"Error: {e}")
        sys.exit(f"Error: {e}")

# Process and match DocumentDB clusters by tags
def process_docdb(client, tags, operator):
    cluster_ids = []
    try:
        # Get all DocumentDB clusters
        response = client.describe_db_clusters(
            Filters=[{"Name": "engine", "Values": ["docdb"]}]
        )
        clusters = response["DBClusters"]

        # Match clusters by tags
        for cluster in clusters:
            try:
                cluster_arn = cluster["DBClusterArn"]
                cluster_tags = client.list_tags_for_resource(ResourceName=cluster_arn)["TagList"]
                tag_set = {f"{t['Key']}={t['Value']}" for t in cluster_tags}

                if operator == "in" and all(f"{tag['Key']}={tag['Value']}" in tag_set for tag in tags):
                    cluster_ids.append(cluster["DBClusterIdentifier"])
                elif operator == "notin" and all(f"{tag['Key']}={tag['Value']}" not in tag_set for tag in tags):
                    cluster_ids.append(cluster["DBClusterIdentifier"])
            except KeyError as e:
                logger.error(f"KeyError: {e} in cluster {cluster['DBClusterIdentifier']}")
            except Exception as e:
                logger.error(f"Error processing cluster: {e}")
    except Exception as e:
        logger.error(f"Error describing DocumentDB clusters: {e}")
        raise
    return cluster_ids

# Manage clusters (start/stop)
def manage_clusters(client, cluster_ids, action):
    processed = []
    failed = []

    # Use ThreadPoolExecutor for parallel processing of clusters
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = {executor.submit(manage_single_cluster, client, cluster_id, action): cluster_id for cluster_id in cluster_ids}

        for future in futures:
            cluster_id = futures[future]
            try:
                result = future.result()
                if result:
                    processed.append(cluster_id)
                else:
                    failed.append(cluster_id)
            except Exception as e:
                logger.error(f"Error processing cluster {cluster_id}: {e}")
                failed.append(cluster_id)

    return processed, failed

# Start or stop a single cluster
def manage_single_cluster(client, cluster_id, action):
    try:
        # Retrieve current status
        response = client.describe_db_clusters(DBClusterIdentifier=cluster_id)
        cluster_status = response["DBClusters"][0]["Status"].lower()

        if action == "start" and cluster_status == "stopped":
            logger.info(f"Starting cluster {cluster_id}")
            client.start_db_cluster(DBClusterIdentifier=cluster_id)
        elif action == "stop" and cluster_status == "available":
            logger.info(f"Stopping cluster {cluster_id}")
            client.stop_db_cluster(DBClusterIdentifier=cluster_id)
        else:
            logger.warning(f"Cluster {cluster_id} is in '{cluster_status}' state. Skipping {action}.")
            return False
        return True
    except Exception as e:
        logger.error(f"Failed to {action} cluster {cluster_id}: {e}")
        return False

# Convert input tags to AWS-compatible format
def convert_tags(input_tags):
    return [{"Key": k.strip(), "Value": v.strip()} for k, v in input_tags.items()]
