import boto3
import logging
from os import getenv
from json import loads

logger = logging.getLogger()
handler = logger.handlers[0]
handler.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(levelname)s:%(funcName)s:%(lineno)s:%(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
)
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    lambda_configs = loads(getenv("lambda_configs"))
    region_name = lambda_configs["region"]
    input_tags = event["tags"]
    action = event["action"]
    operator = event.get("operator", "in")
    cluster_process = []
    try:
        tags = convert(input_tags)
        session = boto3.session.Session()
        client = session.client(
            service_name="redshift",
            region_name=region_name
        )
        cluster_ids = process_redshift(client, tags, operator)
        logger.info(f"{action} action for Redshift clusters {cluster_ids}")

        if action.lower() == "start":
            cluster_process = start(client, cluster_ids)
        elif action.lower() == "stop":
            cluster_process = stop(client, cluster_ids)
        clusters_remain = [i for i in cluster_ids if i not in cluster_process]
        return (f"Redshift!!! Finished {action} process for {cluster_process}, failed process for {clusters_remain if clusters_remain != [] else 'none'}")
    except Exception as e:
        logger.error(f"Error occur: {e}")
        return f"Error occurred: {str(e)}"

def process_redshift(client, input_tags, operator):
    cluster_process = []
    try:
        redshift_clusters = client.describe_clusters()
        logger.info(f"Total Redshift clusters found: {len(redshift_clusters.get('Clusters', []))}")
        
        for cluster in redshift_clusters.get("Clusters", []):
            try:
                cluster_identifier = cluster.get("ClusterIdentifier")
                if not cluster_identifier:
                    logger.warning(f"Cluster without identifier found, skipping")
                    continue
                
                logger.info(f"Processing cluster: {cluster_identifier}")
                cluster_arn = f"arn:aws:redshift:{client.meta.region_name}:{cluster['ClusterNamespaceArn'].split(':')[4]}:cluster:{cluster_identifier}"
                cluster_tags = client.describe_tags(
                    ResourceName=cluster_arn
                ).get("TaggedResources", [])
                
                cluster_tag_list = [{"Key": tag["Tag"]["Key"], "Value": tag["Tag"]["Value"]} for tag in cluster_tags]
                logger.info(f"Tags for cluster {cluster_identifier}: {cluster_tag_list}")
                
                should_process = False
                if operator == "in":
                    should_process = all(tag in cluster_tag_list for tag in input_tags)
                elif operator == "notin":
                    should_process = all(tag not in cluster_tag_list for tag in input_tags)
                
                if should_process:
                    cluster_process.append(cluster_identifier)
                    logger.info(f"Cluster {cluster_identifier} will be processed")
                else:
                    logger.info(f"Cluster {cluster_identifier} does not match criteria, skipping")
                
            except KeyError as e:
                logger.error(f"KeyError for cluster {cluster.get('ClusterIdentifier', 'Unknown')}: {e}")
            except Exception as e:
                logger.error(f"Error processing cluster {cluster.get('ClusterIdentifier', 'Unknown')}: {str(e)}")
                continue
    except Exception as e:
        logger.error(f"Error while processing Redshift: {e}")
        raise
    
    logger.info(f"Clusters to be processed: {cluster_process}")
    return cluster_process

def start(client, cluster_ids):
    cluster_process = []
    for cluster_id in cluster_ids:
        try: 
            logger.info(f"Start action for Redshift cluster {cluster_id}")
            response = client.resume_cluster(
                ClusterIdentifier=cluster_id
            )
            cluster_process.append(cluster_id)
            logger.info(f"Started cluster {cluster_id}")
        except Exception as e:
            logger.error(f"Error while starting Redshift Cluster: {cluster_id}")
            logger.error(f"Error: {e}")
            continue
    logger.info(f"Finished start clusters: {cluster_process}")
    return cluster_process
            
def stop(client, cluster_ids):
    cluster_process = []
    for cluster_id in cluster_ids:
        try:
            logger.info(f"Stop action for Redshift cluster {cluster_id}")
            response = client.pause_cluster(
                ClusterIdentifier=cluster_id
            )
            cluster_process.append(cluster_id)
            logger.info(f"Stopped cluster {cluster_id}")
        except Exception as e:
            logger.error(f"Error while stopping Redshift Cluster: {cluster_id}")
            logger.error(f"Error: {e}")
            continue
    logger.info(f"Finished stop clusters: {cluster_process}")
    return cluster_process

def convert(input):
    tags = []
    for k, v in input.items():
        tags.append({"Key": k.strip(), "Value": v.strip()})
    return tags
