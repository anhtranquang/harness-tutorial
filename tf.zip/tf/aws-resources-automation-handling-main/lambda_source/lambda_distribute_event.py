import sys, logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    input_tags = event["tags"]
    action = event["action"]
    resource_type = event["resource_type"]
    operator   = event.get("operator", "in")
    account_id = event["account_id"]
    try:
        event_info = {
            "action" : action,
            "tags" : input_tags,
            "type" : resource_type,
            "operator": operator,
            "account_id": account_id
        }
        return event_info
    except Exception as e:
        logger.error(f"Error occur: {e}")
        sys.exit("Error!!")
