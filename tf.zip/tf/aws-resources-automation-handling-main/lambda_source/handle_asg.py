import boto3, sys
import logging
import concurrent.futures
from os import getenv
from json import loads,dumps
from multiprocessing import Process
logger = logging.getLogger()
handler = logger.handlers[0]
handler.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(levelname)s:%(funcName)s:%(lineno)s:%(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
)
logger.setLevel(logging.INFO)
ec2_client = boto3.client(service_name="ec2")
asg_client = boto3.client(service_name="autoscaling")
ssm_client = boto3.client(service_name="ssm")

def lambda_handler(event, context):
    lambda_configs = loads(getenv("lambda_configs"))
    input_tags = event["tags"]
    action = event["action"]
    operator = event.get("operator", "in")
    instance_process = []
    try:
        filters = convert(input_tags)
        asg_instances = list_asg_instances(asg_client, filters, operator)
        # print(f"asg_instances: {asg_instances}")
        for asg in asg_instances:
            params = get_param(ssm_client, asg)
            if params == 1:
                put_params(ssm_client, asg)
            if action.lower() == "start":
                instance_process = start(ec2_client,asg, params, asg_client)
            elif action.lower() == "stop":
                instance_process = stop(ec2_client, ssm_client, asg, asg_client)
        instance_remain = [i for i in asg_instances if i not in instance_process]
        return ("ASG!!! Finished {} process for {}, failed proccess for {}".format(action, instance_process, instance_remain if instance_remain != [] else "none"))
        # return ("ASG!!! Finished {} process for {}".format(action, asg_instances))
    except Exception as e:
        logger.error(f"Error occur: {e}")
        sys.exit("Error!!")

def list_asg_instances(client, filters, operator):
    asgs = []
    ca_unmanaged = []
    all_asgs_is_eks_ids = []
    filtered_asgs_ids = []
    asg_to_process = []
    filtered_asgs = []
    res_list = []
    try:
        all_asgs = client.describe_auto_scaling_groups() # All AutoScaling Group
        all_asgs_is_eks = client.describe_auto_scaling_groups(
            Filters=[{"Name": f"tag:k8s.io/cluster-autoscaler/enabled", "Values": ["true"]}]
        ) # Autoscaling group managed by EKS Cluster Autoscaler
        for filter in filters:
            filtered_asg = client.describe_auto_scaling_groups(
                Filters=[filter]) # Autoscaling group filtered with input tag
            filtered_asgs.append(filtered_asg)
        for ids in all_asgs_is_eks["AutoScalingGroups"]:
            all_asgs_is_eks_ids.append(ids["AutoScalingGroupName"]) # List asg name of all asg
        list_asg_after_filter_tags = filter_asg_by_tags(filtered_asgs)
        for i in range(len(list_asg_after_filter_tags)):
            if list_asg_after_filter_tags[i] not in list_asg_after_filter_tags[i + 1:]: # List deduplication
                res_list.append(list_asg_after_filter_tags[i])
        for ids in res_list:
            filtered_asgs_ids.append(ids["AutoScalingGroupName"]) # List asg name of all asg has scheduler tag
        for asg in all_asgs["AutoScalingGroups"]:
            if asg["AutoScalingGroupName"] not in all_asgs_is_eks_ids:
                ca_unmanaged.append(asg)    # List asg name of all asg not managed by CA
        match operator:
            case "notin":
                for asg_not_eks in ca_unmanaged: ### not in EKS
                    if asg_not_eks["AutoScalingGroupName"] not in filtered_asgs_ids:
                        asg_to_process.append(asg_not_eks)
            case "in":
                for asg_ca_unmanaged in ca_unmanaged:
                    if asg_ca_unmanaged["AutoScalingGroupName"] in filtered_asgs_ids:
                        asg_to_process.append(asg_ca_unmanaged)
        for asg in asg_to_process:
            try:
                asgs.append({"instances":asg["Instances"],"name": asg["AutoScalingGroupName"], "desired":asg["DesiredCapacity"], "min": asg["MinSize"], "max": asg["MaxSize"]})
            except Exception as e:
                logger.error(f"Error occur: {e}")
                continue
    except Exception as e:
        logger.error(f"Func: list_asg_instances. Error while process ASG: {e}")
        raise
    logger.debug(f"Func: list_asg_instances. Autoscaling groups: {asgs}")
    return asgs

def start(ec2_client, asg, params, asg_client):
    instance_process = []
    instance_ids = asg["instances"]
    asg_name = asg["name"]
    logger.info(f"Action Start for EC2 Instances {instance_ids}")

    def start_instance(instance):
        id = instance["InstanceId"]
        try:
            logger.info(f"Starting instance: {id}")

            # Start the EC2 instance
            response_start = ec2_client.start_instances(
                InstanceIds=[id],
                AdditionalInfo="Instance start by scheduler"
            )

            if response_start['ResponseMetadata']['HTTPStatusCode'] == 200:
                logger.info(f"Instance {id} is starting...")

            return id

        except Exception as e:
            logger.error(f"Error while starting instance {id}: {e}")
            return None

    def wait_instance_ready(instance):
        id = instance["InstanceId"]
        try:
            # Wait for the instance to reach the 'running' state and be ready
            logger.info(f"Waiting for instance {id} to become ready")
            waiter = ec2_client.get_waiter("instance_status_ok")
            waiter.wait(InstanceIds=[id])
            logger.info(f"Instance {id} is now running and healthy")
            return id

        except Exception as e:
            logger.error(f"Error while waiting for instance {id} to be ready: {e}")
            return None

    def exit_standby(instance):
        id = instance["InstanceId"]
        try:
            # Get the instance's current lifecycle state from the ASG
            instance_state = next(
                (i for i in asg["instances"] if i["InstanceId"] == id), {}
            ).get("LifecycleState")
    
            if instance_state == "Standby":
                logger.info(f"Exiting standby for instance: {id}")
                response_exit = asg_client.exit_standby(
                    InstanceIds=[id],
                    AutoScalingGroupName=asg_name
                )
    
                if response_exit['ResponseMetadata']['HTTPStatusCode'] == 200:
                    logger.info(f"Instance {id} has exited standby")
                    return id
                else:
                    logger.error(f"Failed to exit standby for instance {id}: {response_exit}")
                    return None
            else:
                logger.info(f"Instance {id} is not in standby, skipping exit standby")
                return id
    
        except Exception as e:
            logger.error(f"Error while exiting standby for instance {id}: {e}")
            return None

    # Use ThreadPoolExecutor to start instances concurrently
    with concurrent.futures.ThreadPoolExecutor() as executor:
        future_to_instance = {executor.submit(start_instance, instance): instance for instance in instance_ids}

        started_instances = []
        for future in concurrent.futures.as_completed(future_to_instance):
            instance = future_to_instance[future]
            try:
                result = future.result()
                if result:
                    started_instances.append(result)
            except Exception as e:
                logger.error(f"Error processing instance {instance['InstanceId']}: {e}")

    logger.info(f"Started instances: {started_instances}")

    # Wait for all instances to be fully ready (running and healthy)
    with concurrent.futures.ThreadPoolExecutor() as executor:
        future_to_wait = {executor.submit(wait_instance_ready, instance): instance for instance in instance_ids}

        ready_instances = []
        for future in concurrent.futures.as_completed(future_to_wait):
            instance = future_to_wait[future]
            try:
                result = future.result()
                if result:
                    ready_instances.append(result)
            except Exception as e:
                logger.error(f"Error waiting for instance {instance['InstanceId']} to be ready: {e}")

    logger.info(f"All instances are ready: {ready_instances}")

    # Exit standby for all ready instances
    with concurrent.futures.ThreadPoolExecutor() as executor:
        future_to_exit = {executor.submit(exit_standby, instance): instance for instance in instance_ids}

        exited_instances = []
        for future in concurrent.futures.as_completed(future_to_exit):
            instance = future_to_exit[future]
            try:
                result = future.result()
                if result:
                    exited_instances.append(result)
            except Exception as e:
                logger.error(f"Error while exiting standby for instance {instance['InstanceId']}: {e}")

    logger.info(f"Instances exited standby: {exited_instances}")

    # Once all instances have exited standby, update the ASG capacity
    try:
        min_size = params["min"]
        max_size = params["max"]
        desired = params["desired"]

        response_update = asg_client.update_auto_scaling_group(
            AutoScalingGroupName=asg_name,
            MinSize=min_size,
            MaxSize=max_size,
            DesiredCapacity=desired
        )

        if response_update['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info(f"Updated ASG {asg_name} capacity successfully")

    except Exception as e:
        logger.error(f"Error updating ASG {asg_name} capacity: {e}")

    instance_process.append(asg)

    logger.info(f"Finished starting instances for ASG: {asg_name}")
    return instance_process
    
def stop(ec2_client, ssm_client, asg, asg_client):
    instance_process = []
    instance_ids = asg["instances"]
    asg_name = asg["name"]
    logger.info(f"Action Stop for Autoscaling Group {instance_ids}")
    logger.info(f"Update {asg_name} min size to 0!!")

    asg_client.update_auto_scaling_group(
        AutoScalingGroupName=asg_name,
        MinSize=0
    )

    def stop_instance(instance):
        id = instance["InstanceId"]
        lifecycle_state = instance["LifecycleState"]
        protected_from_scale_in = instance['ProtectedFromScaleIn']
        try:
            logger.info(f"Check instance {id} state: {lifecycle_state}")

            if lifecycle_state == 'Standby':
                logger.info(f"{id} is already in Standby. Proceeding to stop the instance.")
            elif lifecycle_state == 'InService':
                if protected_from_scale_in:
                    logger.info(f"{id} is protected from scale in, skipping.")
                    return

                logger.info(f"Entering standby for instance {id}")
                response = asg_client.enter_standby(
                    InstanceIds=[id],
                    AutoScalingGroupName=asg_name,
                    ShouldDecrementDesiredCapacity=True
                )

                if response['ResponseMetadata']['HTTPStatusCode'] != 200:
                    logger.error(f"Error entering standby for instance {id}: {response}")
                    return

            else:
                logger.info(f"Instance {id} is in an unsupported state: {lifecycle_state}. Skipping.")
                return

            if is_spot_instance(ec2_client, id):
                logger.info(f"{id} is a Spot Instance, skipping.")
                return

            logger.info(f"Stopping instance {id}")
            response = ec2_client.stop_instances(InstanceIds=[id])

            if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                logger.info(f"Successfully stopped instance {id}")
                return id

        except Exception as e:
            logger.error(f"Error while stopping ASG instance {id}: {e}")

    # Use ThreadPoolExecutor for concurrency
    with concurrent.futures.ThreadPoolExecutor() as executor:
        future_to_instance = {executor.submit(stop_instance, instance): instance for instance in instance_ids}

        stopped_instances = []
        for future in concurrent.futures.as_completed(future_to_instance):
            instance = future_to_instance[future]
            try:
                result = future.result()
                if result:
                    stopped_instances.append(result)
            except Exception as e:
                logger.error(f"Error processing instance {instance['InstanceId']}: {e}")

    logger.info(f"Stopped instances: {stopped_instances}")
    instance_process.append(asg)

    # Save state if there were any running instances that were stopped
    if stopped_instances:
        put_params(ssm_client, asg)

    logger.info(f"Finished stop instances for ASG: {asg_name}")
    return instance_process

def get_param(client, asg):
    asg_name = asg["name"]
    try:
        param = client.get_parameter(Name=f"/scheduler/asg/{asg_name}")
        return loads(param["Parameter"]["Value"])
    except Exception as e:
        logger.error(f"Func: get_param. Error: {e}")
        return 1

def put_params(client, asg):
    asg_name = asg["name"]
    desired = asg["desired"]
    min_size = asg["min"]
    max_size = asg["max"]
    value = dumps({"desired": desired, "min": min_size, "max": max_size})
    logger.info(f"Start to put scheduler asg param for: {asg_name}")
    try:
        params = [
            {
            "Name": "/scheduler/asg/" + asg_name,
            "Value": str(value),
            "Type": "String",
            "Overwrite": True
            }
        ]
        client.put_parameter(**params[0])
    except Exception as e:
        logger.error(f"Func: put_params. Error: {e}")
        return 1
        
def convert(input):
    filters = []
    for k, v in input.items():
        filters.append({"Name": f"tag:{k.strip()}", "Values": [v.strip()]})
    return filters

def is_spot_instance(client, instance_id):
    print("check spot instance")
    try:
        instance_detail = client.describe_instances(
            InstanceIds=[instance_id],
        )
        for r in instance_detail["Reservations"]:
            for i in r["Instances"]:
                print(i)
                return  "SpotInstanceRequestId" in i
    except Exception as e:
        logger.error(f"Func: is_spot_instance. Error: {e}")


def filter_asg_by_tags(filtered_asgs):
    list_asg_filtered = []
    for asg in filtered_asgs:
        for asg_detail in asg["AutoScalingGroups"]:
            list_asg_filtered.append(asg_detail)
    return list_asg_filtered
