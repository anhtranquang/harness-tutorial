import boto3, sys, botocore
import logging
from json import loads, dumps
logger = logging.getLogger()
handler = logger.handlers[0]
handler.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(levelname)s:%(funcName)s:%(lineno)s:%(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
)
logger.setLevel(logging.INFO)
transition_rule = {
    'ID' : 'reconcile-managed-rule',
    'Filter': {'Prefix': ''},
    'Status': 'Enabled',
    'Transitions': [
        {
            'Days': 0,
            'StorageClass': 'INTELLIGENT_TIERING'
        }
    ]
}

def lambda_handler(event, context):
    action = event["action"]
    s3 = boto3.client('s3')
    ssm = boto3.client('ssm')
    try:
        for bucket in s3.list_buckets()["Buckets"]:
            bucket_name = bucket['Name']
            if s3.get_bucket_location(Bucket=bucket_name)['LocationConstraint'] == 'ap-southeast-1':
                if action.lower() == "reconcile":
                    try:
                        response = s3.get_bucket_lifecycle_configuration(
                            Bucket=bucket_name)
                        logger.info(f"response {response}")
                        if not check_transition_exists(response["Rules"]):
                            put_params(ssm, response["Rules"], bucket_name)
                            update_transition_rule(bucket_name, s3, response["Rules"])
                        else:
                            logger.info(f"{bucket_name} is good")
                    except botocore.exceptions.ClientError as error:
                        if error.response['Error']['Code'] == "NoSuchLifecycleConfiguration":
                            put_transition_rule(bucket_name, s3, [transition_rule])
                            logger.error(f"Bucket no policy: {bucket_name}")
                        else:
                            raise error
                elif action.lower() == "revert":
                    logger.info(f"revert policy for bucket {bucket_name}")
                    old_rule = get_param(ssm, bucket_name)
                    delete_bucket_lifecycle(bucket_name, s3)
                    put_transition_rule(bucket_name, s3, old_rule)
            
    except Exception as e:
        logger.error(f"Error occur: {e}")
        sys.exit("Error!!")

def delete_bucket_lifecycle(bucket_name, client):
    logger.info(f"{bucket_name} need to delete_bucket_lifecycle to revert")
    try: 
        response = client.delete_bucket_lifecycle(
            Bucket=bucket_name
            )
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info(f"{bucket_name} finished to delete_bucket_lifecycle")
        else:
            logger.error(f"{bucket_name} error to delete_bucket_lifecycle, Code {response['ResponseMetadata']['HTTPStatusCode']}")
    except Exception as e:
        logger.error(f"Error occur delete_bucket_lifecycle: {e}")


def put_transition_rule(bucket_name, client, rule):
    logger.info(f"{bucket_name} need to put_transition_rule")
    try: 
        response = client.put_bucket_lifecycle_configuration(
            Bucket=bucket_name,
            LifecycleConfiguration={
                'Rules': rule
                }
            )
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info(f"{bucket_name} finished to put_transition_rule")
        else:
            logger.error(f"{bucket_name} error to put_transition_rule, Code {response['ResponseMetadata']['HTTPStatusCode']}")
    except Exception as e:
        logger.error(f"Error occur put_transition_rule: {e}")

def update_transition_rule(bucket_name, client, old_rules):
    logger.info(f"{bucket_name} need to update_transition_rule")
    try: 
        merged_rule = map(merge_rule, old_rules)
        list_rules =  list(merged_rule)
        if old_rules == list_rules:
            list_rules.append(transition_rule)
        logger.info(f"list_rules after: {list_rules}")
        response = client.put_bucket_lifecycle_configuration(
            Bucket=bucket_name,
            LifecycleConfiguration={
                'Rules': list_rules
                }
            )
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info(f"{bucket_name} finished to update_transition_rule")
        else:
            logger.error(f"{bucket_name} error to update_transition_rule, Code {response['ResponseMetadata']['HTTPStatusCode']}")
    except Exception as e:
        logger.error(f"Error occur update_transition_rule: {e}")

def check_transition_exists(rules):
    try: 
        for rule in rules:
            if "Transitions" in rule:
                return True
        return False
    except Exception as ex:
        logger.error(f"Error check transition: {ex}")
        return False
        
def merge_rule(old_rule):
    if old_rule["Filter"].get("Prefix","") == "":
        return {**old_rule, **transition_rule}
    else:
        return old_rule

def put_params(client, old_rule, bucket_name):
    logger.info(f"Start to put scheduler ssm param for: {bucket_name}")
    try:
        params = [
            {
            "Name": "/reconciliation/s3/" + bucket_name,
            "Value": str(dumps(old_rule)),
            "Type": "String",
            "Overwrite": True
            }
        ]
        response = client.put_parameter(**params[0])
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info(f"{bucket_name} finished to put ssm params")
        else:
            logger.error(f"{bucket_name} error to put ssm params, Code {response['ResponseMetadata']['HTTPStatusCode']}")
    except Exception as e:
        logger.error(f"Func: put_params. Error: {e}")
        return 1
        
def get_param(client, bucket_name):
    logger.info(f"Start to get scheduler ssm param for: {bucket_name}")
    try:
        param = client.get_parameter(Name=f"/reconciliation/s3/{bucket_name}")
        if param['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info(f"{bucket_name} finished to get ssm params")
        else:
            logger.error(f"{bucket_name} error to get ssm params, Code {param['ResponseMetadata']['HTTPStatusCode']}")
        return loads(param["Parameter"]["Value"])
    except Exception as e:
        logger.error(f"Func: get_param. Error: {e}")
        return 1
    
