import boto3, sys
import logging
from json import dumps
logger = logging.getLogger()
handler = logger.handlers[0]
handler.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(levelname)s:%(funcName)s:%(lineno)s:%(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
)
logger.setLevel(logging.INFO)
cloudwatch = boto3.client('cloudwatch')
ssm = boto3.client('ssm')
ec2 = boto3.client('ec2')
events = boto3.client(service_name="events")

def lambda_handler(event, context):
    account_id = event["account_id"]
    bus_arn = f"arn:aws:events:ap-southeast-1:{account_id}:event-bus/central-event-bus"
    try:
        list_instance_id = list_all_ec2_instances()
        set_linux_instance_id = list_all_linux_instance_has_metric()
        set_window_instance_id = list_all_window_instance_has_metric()
        list_remain = list(set(list_instance_id) - set_linux_instance_id - set_window_instance_id)
        dict_return = list_to_dict(account_id, list_remain)
        put_event(bus_arn, dict_return)
    except Exception as e:
        logger.error(f"Error occur: {e}")
        sys.exit("Error!!")

def put_event(bus_name, data):
    try:
        detail_json = dumps({"content": data})
        entry = {
            "Source": "platform.vpb.io",
            "Resources": ["platform.vpb.io"],
            "DetailType": "CW Agent Discovery",
            "Detail": str(detail_json),
            "EventBusName": bus_name,
        }
        response = events.put_events(
            Entries=[entry],
        )

        if response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            logger.info(f"Events send successfully")
        else:
            logger.error(
                f"Events send failed, Error response: {response}"
            )
    except Exception as e:
        logger.error(e)
        return "Failed!!"
    
def list_all_ec2_instances():
    list_instance_id = []
    try:
        paginator = ec2.get_paginator('describe_instances')
        response_iterator = paginator.paginate(
            Filters=[
            {'Name': 'instance-state-name', 'Values': ['running', 'pending', 'shutting-down', 'stopping', 'stopped']}  
            ])
        for response in response_iterator:
            for r in response["Reservations"]:
                for i in r["Instances"]:
                    instance_id = i["InstanceId"]
                    try:
                        if should_ignore(i["Tags"]):
                            continue
                        else:
                            list_instance_id.append(instance_id)
                    except KeyError as e:
                        logger.error(f"KeyError: {e}, instance {instance_id}")
                        continue
    except Exception as e:
        logger.error(f"Error occur: {e}")
    return list_instance_id

def list_all_linux_instance_has_metric():
    set_instance_ids = set()
    try:
        paginator = cloudwatch.get_paginator('list_metrics')
        response_iterator = paginator.paginate(
            Namespace='CWAgent',
            MetricName='disk_used_percent',
            Dimensions=[
                {
                    'Name': 'InstanceId'
                },
            ]
        )
        for response in response_iterator:
            for r in response["Metrics"]:
                for d in r["Dimensions"]:
                    name = d.get("Name")
                    if(name == "InstanceId"):
                        set_instance_ids.add(d["Value"])
                continue
    except Exception as e:
        logger.error(f"Error occur: {e}")
    return set_instance_ids

def list_all_window_instance_has_metric():
    set_instance_ids = set()
    try:
        paginator = cloudwatch.get_paginator('list_metrics')
        response_iterator = paginator.paginate(
            Namespace='CWAgent',
            MetricName='LogicalDisk % Free Space',
            Dimensions=[
                {
                    'Name': 'InstanceId'
                },
            ]
        )
        for response in response_iterator:
            for r in response["Metrics"]:
                for d in r["Dimensions"]:
                    name = d.get("Name")
                    if(name == "InstanceId"):
                        set_instance_ids.add(d["Value"])
                continue
    except Exception as e:
        logger.error(f"Error occur: {e}")
    return set_instance_ids

def should_ignore(instance_tags):
    '''
        Return True if an instance should be ignored by instance scheduler.
        Currently we ignore if the instance is managed by Karpenter or Cloud9
        by looking at its tags
    
        Parameters:
            tags -- list of Key/Value tag object

        Returns:
            True if instance tags has a key name karpenter.sh/managed-by or aws:cloud9:owner
            False otherwise.
    '''
    
    for tag in instance_tags:
        if tag["Key"] in ["aws:eks:cluster-name","aws:cloud9:owner"]:
            return True
    
    return False

def list_to_dict(account_id, list_to_convert):
    dict_return = []
    for i in list_to_convert:
        dict_return.append({"AccountID": account_id, "InstanceID": i})
    return dict_return
