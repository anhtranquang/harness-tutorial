import boto3, sys
import logging, time
from json import loads
from os import getenv
from multiprocessing import Process
logger = logging.getLogger()
handler = logger.handlers[0]
handler.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(levelname)s:%(funcName)s:%(lineno)s:%(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
)
logger.setLevel(logging.INFO)
cw = boto3.client('cloudwatch')


def lambda_handler(event, context):
    try:
        lambda_configs = loads(getenv("lambda_configs"))
        event_tags = event["detail"]["tags"]
        instance_id = event["resource"]
        default_tags = lambda_configs["tags"]
        if default_tags not in event_tags.items():
            list_alarm = list_alarms_with_prefix(instance_id)
            delete_cw_alarm(list_alarm)
    except Exception as e:
        logger.error(f"Error occur: {e}")
        sys.exit("Error!!")

def delete_cw_alarm(list_alarm):
    try:
        response = cw.delete_alarms(
            AlarmNames=list_alarm
        )
        if response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            logger.info(f"delete_cw_alarm successfully")
        else:
            logger.error(f"delete_cw_alarm failed, Error response: {response}")
            raise Exception
    except Exception as e:
        logger.error(f"Error: {e}")

def list_alarms_with_prefix(instance_id):
    alarm_prefix=f"EBS_Utilization_Overhead_{instance_id}"
    alarm_list = []
    try:
        response = cw.describe_alarms(
            AlarmNamePrefix=alarm_prefix,
        )
        if response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            logger.info(f"list_alarms_with_prefix successfully")
        else:
            logger.error(f"list_alarms_with_prefix failed, Error response: {response}")
            raise Exception
        for r in response["MetricAlarms"]:
            alarm_list.append(r["AlarmName"])
    except Exception as e:
        logger.error(f"Error: {e}")
    return alarm_list
