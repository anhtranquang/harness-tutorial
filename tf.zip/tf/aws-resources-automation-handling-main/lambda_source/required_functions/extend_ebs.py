import boto3
import logging, time
from datetime import datetime, timedelta
logger = logging.getLogger()
handler = logger.handlers[0]
handler.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(levelname)s:%(funcName)s:%(lineno)s:%(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
)
logger.setLevel(logging.INFO)
ssm = boto3.client('ssm')
ec2 = boto3.client('ec2')
cw  = boto3.client('cloudwatch')

def lambda_handler(event, context):
    metrics = event["alarmData"]["configuration"]["metrics"]
    mount_point, device, instance_id, instance_type, image_id, fstype = process_metrics(metrics)
    datapoints = get_metrics_statistic(device, instance_id, mount_point,  instance_type, image_id, fstype)
    print(f"datapoints {datapoints}")
    if len(datapoints) > 0:
        volume_id = get_volume_id(instance_id, device)
        size = get_volume_size(volume_id)
        data = float(datapoints[0]["Maximum"])
        new_size = 0.0
        if data >= 70.0 and data < 80.0:
            new_size = round(float(size*110/100))
        elif data >= 80.0 and data < 90.0:
            new_size = round(float(size*120/100))
        elif data> 90:
            new_size = round(float(size*150/100))
        print(volume_id)
        print(size)
        print(data)
    # size = int(size) + 30
    if new_size != 0.0:
        start_automation_execution(instance_id, mount_point, volume_id, new_size)
    return 1

def get_volume_id(instance_id, device):
    try:
        response = ssm.send_command(
            InstanceIds=[instance_id],
            DocumentName="AWS-RunShellScript",
            Parameters={'commands': ['nvme id-ctrl -v /dev/{} | grep vol | awk \'{{print $3}}\' | sed \'s|vol|vol-|g\''.format(device)]}, 
        )

        command_id = response['Command']['CommandId']
        time.sleep(2)
        output = ssm.get_command_invocation(
            CommandId=command_id,
            InstanceId=instance_id,
        )
        if output["StatusDetails"] == "Failed":
            raise Exception("Error getting volume id")
    except Exception as e:
        logger.error(f"Error: {e}")
    return output["StandardOutputContent"].strip()

def get_volume_size(vol_id):
    try:
        response = ec2.describe_volumes(
            VolumeIds=[vol_id]
        )
        if response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            logger.info(f"describe_volumes successfully")
        else:
            logger.error(f"describe_volumes failed, Error response: {response}")
            raise Exception
        for r in response["Volumes"]:
            return r["Size"]
    except Exception as e:
        logger.error(f"Error: {e}")

def start_automation_execution(instance_id, mount_point, vol_id, size):
    try:
        response = ssm.start_automation_execution(
            DocumentName='AWS-ExtendEbsVolume',
            DocumentVersion='1',
            Parameters={
                "InstanceId": [
                    instance_id
                ],
                "MountPoint": [
                    mount_point
                ],
                "SizeGib": [
                    str(size)
                ],
                "VolumeId": [
                    vol_id
                ]
            }
        )
        print(f"start_automation_execution {response}")
        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
            logger.info(f"Starting extend ebs volume {vol_id} for instance {instance_id} ")
    except Exception as e:
        logger.error(f"Error: {e}")

def process_metrics(metrics):
    try:
        for metric in metrics:
            dimensions = metric["metricStat"]["metric"]["dimensions"]
            return dimensions["path"], dimensions["device"], dimensions["InstanceId"], dimensions["InstanceType"], dimensions["ImageId"],  dimensions["fstype"]
    except Exception as e:
        logger.error(f"Error: {e}")

def get_metrics_statistic(device, instance_id, mount_path,  instance_type, image_id, fstype):
    try:
        response = cw.get_metric_statistics(
            Namespace='CWAgent',
            MetricName='disk_used_percent',
            Dimensions=[
                {
                    "Name": "path",
                    "Value": str(mount_path)
                },
                {
                    "Name": "InstanceId",
                    "Value": str(instance_id)
                },
                {
                    "Name": "device",
                    "Value": str(device)
                },
                {
                    "Name": "fstype",
                    "Value": str(fstype)
                },
                {
                    "Name": "InstanceType",
                    "Value": str(instance_type)
                },
                {
                    "Name": "ImageId",
                    "Value": str(image_id)
                },
            ],
            StartTime = datetime.now() - timedelta(seconds = 500),
            EndTime = datetime.now(),
            Period=300,
            Statistics=['Maximum'])
    except Exception as e:
        logger.error(f"Error: {e}")
    return response["Datapoints"]
