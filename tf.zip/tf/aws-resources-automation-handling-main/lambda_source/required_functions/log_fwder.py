from kafka import KafkaProducer
import json
from base64 import b64decode
import gzip
import boto3
def lambda_handler(event, context):
    decoded_data = gzip.decompress(b64decode(event['awslogs']['data']))
    data = json.loads(decoded_data)
    print(data)
    log_events = data.get("logEvents")
    owner_id = data.get("owner")
    log_group = data.get("logGroup")
    log_stream = data.get("logStream")
    try:
        producer = KafkaProducer(
                bootstrap_servers = ['stream.aws.platform.vpbank.dev:9096'], # server name
                value_serializer = json_serializer, # function callable,
                sasl_mechanism  = "SCRAM-SHA-512",
                sasl_plain_username = "platform",
                sasl_plain_password  = "rkuWthtmFw39VzThPXH40uj91CnN8Rjx",
                security_protocol = "SASL_SSL"
        )
        for log in log_events:
            # log = json.loads(json.dumps(log))
            print(log)
            producer.send(owner_id,{"account_id": owner_id, "log_group": log_group, "log_stream": log_stream,"timestamp": log.get("timestamp"), "message": log.get("message")})
    except Exception as e:
        print(e)
    return 1

def json_serializer(data):
    return json.dumps(data).encode('utf-8')
