import boto3, sys
import logging
from os import getenv
from json import loads
logger = logging.getLogger()
handler = logger.handlers[0]
handler.setFormatter(
    logging.Formatter(
        "[%(asctime)s] %(levelname)s:%(funcName)s:%(lineno)s:%(message)s",
        "%Y-%m-%d %H:%M:%S",
    )
)
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    lambda_configs = loads(getenv("lambda_configs"))
    region_name = lambda_configs["region"]
    input_tags = event["tags"]
    operator   = event.get("operator", "in")
    action = event["action"]
    instance_process = {}
    try:
        tags = convert(input_tags)
        session = boto3.session.Session()
        asg_instances = list_asg_instances(session, region_name)
        client = session.client(
            service_name="ec2",
            region_name=region_name
        )
        instance_ids = filter_ec2_instances(client, tags, asg_instances, operator)
        if action.lower() == "start":
            instance_process = start(client, instance_ids)
        elif action.lower() == "stop":
            instance_process = stop(client, instance_ids)
        instance_remain = [i for i in instance_ids if i not in instance_process]
        return ("EC2!!! Finished {} process for {}, failed proccess for {}".format(action, instance_process, instance_remain if instance_remain != [] else "none"))
    except Exception as e:
        logger.error(f"Error occur: {e}")
        sys.exit("Error!!")

def filter_ec2_instances(client, tags, asg_instances, operator):
    '''
        Filter EC2 instances should be processed next
        ignore those in ASG (will be handled by handle_asg function), those that managed by Karpenter, etc...
    
        Parameters:
            client -- AWS EC2 client
            tags -- 
            asg_instances -- list of the instance ids that are managed by ASG so we can filter out
            operator -- operator (in/notin)

        Returns:
            a list of instance ids that should be processed next
    '''
    
    instance_process = []
    try:
        response = client.describe_instances()
        for r in response["Reservations"]:
            for i in r["Instances"]:
                instance_id = i["InstanceId"]
                try:
                    if should_ignore(i["Tags"]):
                        continue
                    else:
                            match operator:
                                case "in":
                                    if(all(x in i["Tags"] for x in tags)):
                                        if instance_id not in asg_instances:
                                            instance_process.append(instance_id)
                                        else:
                                            logger.debug("Instance %s in ASG, ignored", instance_id)
                                case "notin":
                                    if(all(x not in i["Tags"] for x in tags)):
                                        if instance_id not in asg_instances:
                                            instance_process.append(instance_id)
                                        else:
                                            logger.debug("Instance %s in ASG, ignored", instance_id)
                except KeyError as e:
                    logger.error(f"KeyError: {e}, instance {instance_id}")
                    continue
                except Exception as e:
                    logger.error(f"Error occur: {type(e).__name__}")
                    continue
    except Exception as e:
        logger.error(f"Error while process EC2: {e}")
        raise
    logger.info(f"instances: {instance_process}")
    return instance_process

def list_asg_instances(session, region_name):
    asg_instances = []
    try:
        client = session.client(
            service_name="autoscaling",
            region_name=region_name
        )
        response = client.describe_auto_scaling_instances()
        for r in response["AutoScalingInstances"]:
            try:
                asg_instances.append(r["InstanceId"])
            except Exception as e:
                logger.error(f"Error occur: {type(e).__name__}")
                continue
    except Exception as e:
        logger.error(f"Error while process ASG: {e}")
        raise
    logger.debug(f"ASG instances: {asg_instances}")
    return asg_instances

def start(client, instance_ids):
    '''
        Start all the instances from the instance ids list
    
        Parameters:
            client -- AWS EC2 client
            instance_ids -- list of EC2 instance ids to be started

        Returns:
            a list of instance ids that have already been processed
    '''
    
    instance_process = []
    for instance_id in instance_ids:
        try: 
            logger.info(f"Start action for EC2 Instances {instance_id}")
            response = client.start_instances(
                InstanceIds=[instance_id],
                AdditionalInfo='Instance start by scheduler'
            )
            instance_process.append(instance_id)
            logger.info(f"Started Instance {instance_id}")
        except Exception as e:
            logger.error(f"Error while start EC2 instance: {instance_id}")
            logger.error(f"Error: {e}")
            continue
    logger.info(f"Finished start instances: {instance_process}")
    return instance_process
    

def stop(client, instance_ids):
    '''
        Stop all the instances from the instance ids list
    
        Parameters:
            client -- AWS EC2 client
            instance_ids -- list of EC2 instance ids to be stopped

        Returns:
            a list of instance ids that have already been processed
    '''
    
    instance_process = []
    for instance_id in instance_ids:
        try: 
            logger.info(f"Stop action for EC2 Instance {instance_id}")
            response = client.stop_instances(
                InstanceIds=[instance_id]
            )
            instance_process.append(instance_id)
            logger.info(f"Stopped Instance {instance_id}")
        except Exception as e:
            logger.error(f"Error while stop EC2 instance: {instance_id}")
            logger.error(f"Error: {e}")
            continue
    logger.info(f"Finished stop instances: {instance_process}")
    return instance_process

def convert(input):
    tags = []
    for k, v in input.items():
        tags.append({"Key": k.strip(), "Value": v.strip()})
    return tags

def should_ignore(instance_tags):
    '''
        Return True if an instance should be ignored by instance scheduler.
        Currently we ignore if the instance is managed by Karpenter or Cloud9
        by looking at its tags
    
        Parameters:
            tags -- list of Key/Value tag object

        Returns:
            True if instance tags has a key name karpenter.sh/managed-by or aws:cloud9:owner
            False otherwise.
    '''
    
    for tag in instance_tags:
        if tag["Key"] in ["karpenter.sh/managed-by","aws:cloud9:owner"]:
            return True
    
    return False
