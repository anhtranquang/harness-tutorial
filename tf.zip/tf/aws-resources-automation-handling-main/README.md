# AWS Resources Automation Handling

Terraform module which creates event buses and  state machine to Auto Handling Resources on AWS.

# Usage

```hcl
module "resources-automation-handling" {
  create        = true
  master_prefix = "platform" # TODO: update here
  instance_name             = "automation-handling" # TODO: update here
  vpc_id                    = "vpc-0ff592d2c94fe28bc" # TODO: update here
  security_groups = {
    internal = {
      rules = {
        all_outbound = {
          description = "Permit All traffic outbound"
          type        = "egress", from_port = "0", to_port = "0", protocol = "-1"
          cidr_blocks = ["0.0.0.0/0"]
        }
      }
    }
    external = {
      rules = {
        all_outbound = {
          description = "Permit All traffic outbound"
          type        = "egress", from_port = "0", to_port = "0", protocol = "-1"
          cidr_blocks = ["0.0.0.0/0"]
        }
      }
    }
  }
  network_interfaces = {
    internal = {
      device_index   = 0
      security_group = "internal"
      subnet_ids = [
        "subnet-02c40db91b4e76929", # TODO: update here
        "subnet-0ef4b9ff42978854d" # TODO: update here
      ]
      source_dest_check = false
    }
  }
}
```

## Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 1.3.0 |
| <a name="requirement_archive"></a> [archive](#requirement\_archive) | 2.6.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 5.1.0, < 6.0.0 |
| <a name="requirement_local"></a> [local](#requirement\_local) | 2.5.2 |

## Providers

| Name | Version |
|------|---------|
| <a name="provider_archive"></a> [archive](#provider\_archive) | 2.6.0 |
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 5.1.0, < 6.0.0 |
| <a name="provider_local"></a> [local](#provider\_local) | 2.5.2 |

## Modules

No modules.

## Resources

| Name | Type |
|------|------|
| [aws_cloudwatch_event_bus.central_bus](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_bus) | resource |
| [aws_cloudwatch_event_bus_policy.policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_bus_policy) | resource |
| [aws_cloudwatch_event_rule.distributed_stf_fail_sns_rule](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_rule) | resource |
| [aws_cloudwatch_event_rule.event_fanout](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_rule) | resource |
| [aws_cloudwatch_event_rule.event_invoke](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_rule) | resource |
| [aws_cloudwatch_event_target.cloudwatch_event_target](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_target) | resource |
| [aws_cloudwatch_event_target.distributed_event](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_target) | resource |
| [aws_cloudwatch_event_target.distributed_event_target_sns](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_event_target) | resource |
| [aws_cloudwatch_log_group.distributed](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_log_group) | resource |
| [aws_cloudwatch_log_group.lambda_distributed](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_log_group) | resource |
| [aws_cloudwatch_log_group.lambda_handle](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/cloudwatch_log_group) | resource |
| [aws_iam_policy.policy_cloudwatch_log](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_iam_policy.policy_invoke_lambda](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_iam_policy.policy_publish_sns](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_policy) | resource |
| [aws_iam_role.allow_cloudwatch_to_execute_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.allow_put_events](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.iam_for_sfn](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.lambda_distributed_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role.lambda_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role) | resource |
| [aws_iam_role_policy.lambda_distributed_role_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.lambda_role_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.put_events](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy.state_execution](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy) | resource |
| [aws_iam_role_policy_attachment.iam_for_sfn_attach_policy_invoke_lambda](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_iam_role_policy_attachment.iam_for_sfn_attach_policy_publish_logs](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_iam_role_policy_attachment.iam_for_sfn_attach_policy_publish_sns](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_iam_role_policy_attachment.lambda_handle_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/iam_role_policy_attachment) | resource |
| [aws_lambda_function.lambda_distributed](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_function) | resource |
| [aws_lambda_function.lambda_handle](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_function) | resource |
| [aws_lambda_permission.lambda_handle_permission](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/lambda_permission) | resource |
| [aws_security_group.security_group](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/security_group) | resource |
| [aws_sfn_state_machine.distributed_sfn](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sfn_state_machine) | resource |
| [aws_sns_topic.notification](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sns_topic) | resource |
| [aws_sns_topic_policy.cw_event_permissions](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sns_topic_policy) | resource |
| [aws_sns_topic_subscription.sns_topic_subscription](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/sns_topic_subscription) | resource |
| [archive_file.lambda_archive](https://registry.terraform.io/providers/hashicorp/archive/2.6.0/docs/data-sources/file) | data source |
| [archive_file.lambda_distributed_archive](https://registry.terraform.io/providers/hashicorp/archive/2.6.0/docs/data-sources/file) | data source |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_iam_policy.basic_execution_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy) | data source |
| [aws_iam_policy.vpc_access_execution_role](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy) | data source |
| [aws_iam_policy_document.allow_cloudwatch_to_execute_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.assume_lambda](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.assume_sfn](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.policy_cloudwatch_log](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.policy_invoke_lambda](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.policy_publish_sns](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_iam_policy_document.sns_topic_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_partition.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/partition) | data source |
| [aws_subnets.subnet_ids](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnets) | data source |
| [aws_subnets.subnet_ids_full_ips](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/subnets) | data source |
| [local_file.lambda_handle](https://registry.terraform.io/providers/hashicorp/local/2.5.2/docs/data-sources/file) | data source |

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_additional_tags"></a> [additional\_tags](#input\_additional\_tags) | Tags to add to the security group resource. | `map(string)` | `{}` | no |
| <a name="input_assume_role"></a> [assume\_role](#input\_assume\_role) | AssumeRole to manage the resources within account that owns | `string` | `null` | no |
| <a name="input_aws_region"></a> [aws\_region](#input\_aws\_region) | AWS Region name to deploy resources. | `string` | `"ap-southeast-1"` | no |
| <a name="input_bus_patterns"></a> [bus\_patterns](#input\_bus\_patterns) | Source event bus pattern | `any` | `{}` | no |
| <a name="input_create"></a> [create](#input\_create) | Determines whether to create autoscaling group or not | `bool` | `true` | no |
| <a name="input_create_vpc"></a> [create\_vpc](#input\_create\_vpc) | Controls if VPC should be created (it affects almost all resources) | `bool` | `true` | no |
| <a name="input_custom_kms_arn"></a> [custom\_kms\_arn](#input\_custom\_kms\_arn) | AWS Key Management Service (AWS KMS) customer master key (CMK) to be used for encrypting the build project's. | `string` | `null` | no |
| <a name="input_event_fanout_bus_patterns"></a> [event\_fanout\_bus\_patterns](#input\_event\_fanout\_bus\_patterns) | Source event fanout pattern | `any` | <pre>{<br>  "detail-type": [<br>    "CW Agent Discovery"<br>  ]<br>}</pre> | no |
| <a name="input_event_receiver_bus_arn"></a> [event\_receiver\_bus\_arn](#input\_event\_receiver\_bus\_arn) | Event receiver bus ARN | `string` | `"arn:aws:events:ap-southeast-1:252117944295:event-bus/non-prod-receiver-event-bus"` | no |
| <a name="input_event_vars"></a> [event\_vars](#input\_event\_vars) | Lambda event variable | `any` | <pre>[<br>  {<br>    "bus_patterns": {<br>      "source": [<br>        "aws.events",<br>        "management.events"<br>      ]<br>    },<br>    "enable_vpc": false,<br>    "name": "aurora",<br>    "policies": [<br>      "ec2:CreateNetworkInterface",<br>      "ec2:DescribeInstances",<br>      "ec2:DescribeNetworkInterfaces",<br>      "ec2:DeleteNetworkInterface",<br>      "ec2:AttachNetworkInterface",<br>      "rds:Describe*",<br>      "rds:Start*",<br>      "rds:Stop*",<br>      "kms:CreateGrant"<br>    ],<br>    "runtime": "python3.12",<br>    "timeout": 30,<br>    "variables": {<br>      "region": "ap-southeast-1"<br>    }<br>  }<br>]</pre> | no |
| <a name="input_input_paths"></a> [input\_paths](#input\_input\_paths) | Input paths pattern | `map(string)` | `{}` | no |
| <a name="input_input_template"></a> [input\_template](#input\_input\_template) | Input template pattern | `string` | `null` | no |
| <a name="input_instance_name"></a> [instance\_name](#input\_instance\_name) | Name used across the resources created | `string` | `null` | no |
| <a name="input_lambda_variables"></a> [lambda\_variables](#input\_lambda\_variables) | Lambda distribute event variables | `any` | `{}` | no |
| <a name="input_management_account_ids"></a> [management\_account\_ids](#input\_management\_account\_ids) | Account IDs to allow put event from | `list(string)` | <pre>[<br>  "327253534716"<br>]</pre> | no |
| <a name="input_master_prefix"></a> [master\_prefix](#input\_master\_prefix) | To specify a key prefix for aws resource | `string` | `"non-prod"` | no |
| <a name="input_security_group_name"></a> [security\_group\_name](#input\_security\_group\_name) | Name of the security group. | `string` | `null` | no |
| <a name="input_security_groups"></a> [security\_groups](#input\_security\_groups) | The `security_groups` variable is a map of maps, where each map represents an AWS Security Group.<br>  The key of each entry acts as the Security Group name.<br>  List of available attributes of each Security Group entry:<br>  - `rules`: A list of objects representing a Security Group rule. The key of each entry acts as the name of the rule and<br>      needs to be unique across all rules in the Security Group.<br>      List of attributes available to define a Security Group rule:<br>      - `description`: Security Group description.<br>      - `type`: Specifies if rule will be evaluated on ingress (inbound) or egress (outbound) traffic.<br>      - `cidr_blocks`: List of CIDR blocks - for ingress, determines the traffic that can reach your instance. For egress<br>      Determines the traffic that can leave your instance, and where it can go.<br><br><br>  Example:<pre>security_groups = {<br>    mgmt = {<br>      name = "mgmt"<br>      rules = {<br>        all-outbound = {<br>          description = "Permit All traffic outbound"<br>          type        = "egress", from_port = "0", to_port = "0", protocol = "-1"<br>          cidr_blocks = ["0.0.0.0/0"]<br>        }<br>        https-inbound-private = {<br>          description = "Permit HTTPS"<br>          type        = "ingress", from_port = "443", to_port = "443", protocol = "tcp"<br>          cidr_blocks = ["10.0.0.0/8"]<br>        }<br>        https-inbound-eip = {<br>          description = "Permit HTTPS"<br>          type        = "ingress", from_port = "443", to_port = "443", protocol = "tcp"<br>          cidr_blocks = ["100.100.100.100/32"]<br>        }<br>        ssh-inbound-eip = {<br>          description = "Permit SSH"<br>          type        = "ingress", from_port = "22", to_port = "22", protocol = "tcp"<br>          cidr_blocks = ["100.100.100.100/32"]<br>        }<br>      }<br>    }<br>  }</pre> | <pre>map(object({<br>    name = optional(string)<br>    rules = map(object({<br>      from_port   = string<br>      to_port     = string<br>      protocol    = string<br>      type        = string<br>      cidr_blocks = optional(list(string), null)<br>      description = optional(string)<br>      self        = optional(string)<br>    }))<br>  }))</pre> | <pre>{<br>  "internal": {<br>    "rules": {<br>      "all_outbound": {<br>        "cidr_blocks": [<br>          "0.0.0.0/0"<br>        ],<br>        "description": "Permit All traffic outbound",<br>        "from_port": "0",<br>        "protocol": "-1",<br>        "to_port": "0",<br>        "type": "egress"<br>      }<br>    }<br>  }<br>}</pre> | no |
| <a name="input_sns_topic_arn"></a> [sns\_topic\_arn](#input\_sns\_topic\_arn) | Topic ARN for notifications to be sent through | `string` | `""` | no |
| <a name="input_subcription_emails"></a> [subcription\_emails](#input\_subcription\_emails) | The list email to create AWS sns<br>[<br>  example@example.com<br>] | `list(string)` | `[]` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to add to all resources. | `map(string)` | `{}` | no |
| <a name="input_vpc_id"></a> [vpc\_id](#input\_vpc\_id) | The VPC ID where Security Group will be created. | `string` | `null` | no |

## Outputs

| Name | Description |
|------|-------------|
| <a name="output_central_event_bus"></a> [central\_event\_bus](#output\_central\_event\_bus) | Central event bus name |
| <a name="output_function_arns"></a> [function\_arns](#output\_function\_arns) | Function arns |
